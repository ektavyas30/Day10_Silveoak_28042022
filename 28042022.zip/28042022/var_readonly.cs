using System;

namespace VarObjectReadOnlyConst
{
    class Program
    {
        readonly int r = 1000;
        public Program()
        {
            r = 2000;
        }

        static void Main(string[] args)
        {
         
            var a = "ABC"; 
            
            object o = 100; 
            o = "Abhishek";
            o = 100.100f;
            o = 'A';
            o = true;

            const float PI = 3.14f;

            Program P = new Program();
            
    }
    }
}
